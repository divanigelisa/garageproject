<?php

// klantid uit het formulier halen

$autokenteken = $_POST["autokentekenvak"];

// klantgegevens uit de tabel halen

require_once "gar-connect.php";

$auto = $conn->prepare("SELECT autokenteken, automerk, autotype, autokmstand, klantid FROM klant WHERE autokenteken = :autokenteken ");
$auto->execute(["klantid" => $klantid]);
$car =$auto->fetch(PDO::FETCH_ASSOC);

// klantgegevens in een nieuw formulier laten zien

echo "<form action='gar-update-auto3.php' method='post'>";
{
    // klantid mag niet gewijzigd worden
    echo "autokenteken:" . $car["autokenteken"];
    echo "<input type='hidden' name ='autokentekenvak'";
    echo "value=' " . $car["autokenteken"] . " '> <br /> ";

    echo "automerk: <input type='text' ";
    echo " name = 'automerkvak'";
    echo "value = ' " . $car ["automerk"]. "' ";
    echo "> <br />";

    echo "autotype: <input type='text'";
    echo "name = 'autotypevak'";
    echo "value = '" . $car["autotype"] . "'";
    echo "> <br />";

    echo "autokmstand: <input type='text'";
    echo "name = 'autokmstandvak'";
    echo "value = '" . $car["autokmstand"] . "'";
    echo "> <br />";

    echo "klantplaats: <input type='text'";
    echo "name = 'klantplaatsvak'";
    echo "value = '" . $klant["klantplaats"] . "'";
    echo "> <br />";
}
echo "<input type='submit'>";
echo "</ form>";

