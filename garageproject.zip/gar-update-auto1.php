<!doctype html>
<html lang="nl">
<head> </head>
<body>
<h1> garage update auto 1</h1>
<p> Dit formulier wordt gebruikt om autogegevens te wijzigen.</p>
<form action="gar-update-klant2.php" method="post">
    Welk kenteken wilt u wijzigen?
    <input type="text" name="autokentekenvak"> <br/>
    <input type="submit">
</form>
</body>
</html>