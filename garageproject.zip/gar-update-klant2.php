<?php

// klantid uit het formulier halen

$klantid = $_POST["klantidvak"];

// klantgegevens uit de tabel halen

require_once "gar-connect.php";

$klant = $conn->prepare("SELECT klantid, klantnaam, klantadres, klantpostcode, klantplaats FROM klant WHERE klantid = :klantid ");
$klant->execute(["klantid" => $klantid]);
$client =$klant->fetch(PDO::FETCH_ASSOC);

// klantgegevens in een nieuw formulier laten zien

echo "<form action='gar-update-klant3.php' method='post'>";
{
    // klantid mag niet gewijzigd worden
    echo "klantid:" . $client["klantid"];
    echo "<input type='hidden' name ='klantidvak'";
    echo "value=' " . $client["klantid"] . " '> <br /> ";

    echo "klantnaam: <input type='text' ";
    echo " name = 'klantnaamvak'";
    echo "value = ' " . $klant ["klantnaam"]. "' ";
    echo "> <br />";

    echo "klantadres: <input type='text'";
    echo "name = 'klantadresvak'";
    echo "value = '" . $klant["klantadres"] . "'";
    echo "> <br />";

    echo "klantpostcode: <input type='text'";
    echo "name = 'klantpostcodevak'";
    echo "value = '" . $klant["klantpostcode"] . "'";
    echo "> <br />";

    echo "klantplaats: <input type='text'";
    echo "name = 'klantplaatsvak'";
    echo "value = '" . $klant["klantplaats"] . "'";
    echo "> <br />";
}
    echo "<input type='submit'>";
    echo "</ form>";

