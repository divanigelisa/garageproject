<!DOCTYPE html>
<html lang="en" xmlns:automerk="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="UTF-8">
    <title>gar-create-auto1.php</title>
    <link href="styles.css" type="text/css" rel="stylesheet">
</head>
<body>
<h1> Garage create auto 1</h1>
<form class="auto1" action="gar-create-auto2.php" method="post">
    autokenteken:      <input type="text" name="autokentekenvak"> <br />
    automerk:     <input type="text" name="automerkvak"> <br />
    autotype:  <input type="text" name="autotypevak"> <br/>
    autokmstand:    <input type="text" name="autokmstandvak">  <br />
    klantid:    <input type="text" name="klantidvak">  <br />
    <input type="submit">
</form>
</body>
</html>