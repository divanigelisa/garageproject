<!doctype html>
<html lang="nl">

<head>
<title>gar-zoek-klant1.php</title>
</head>

<body>
<h1> garage zoek op klantid 1</h1>
<p> Dit formulier zoekt een klant op uit de tabel van de database garage.</p>
<form action="gar-zoek-klant2.php" method="post">
    Welk klantid zoekt u?
    <input type="text" name="klantidvak"> <br/>
    <input type="submit">
</form>
</body>

</html>