<!doctype html>
<html lang="nl">

<head>
    <title>gar-zoek-auto1.php</title>
</head>

<body>
<p> Dit formulier zoekt een auto op uit de tabel van de database garage.</p>
<form action="gar-zoek-klant2.php" method="post">
    Welk kenteken zoekt u?
    <input type="text" name="autokentekenvak"> <br/>
    <input type="submit">
</form>
</body>

</html>