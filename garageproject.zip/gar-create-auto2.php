<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>gar-create-auto2.php</title>
    <link href="styles.css" type="text/css" rel="stylesheet">
</head>
<body>
<h1> garage create auto 2 </h1>


<?php

$autokenteken        =NULL; // komt niet uit het formulier (autoincrement)
$automerk      = $_POST["automerkvak"];
$autotype     = $_POST["autotypevak"];
$autokmstand  = $_POST["autokmstandvak"];
$klantid    = $_POST["klantidvak"];

// klantgegevens invoeren in de tabel ---------------------
require_once "gar-connect.php";

$sql = $conn->prepare(" insert into klant values ( :autokenteken, :automerk, :autotype, :autokmstand, :klantid  ) ");

// manier 1 (of manier 2 gebruiken)----------------------
// $sql->bindParam(":klantid",      $klantid);
// $sql->bindParam(":klantnaam"     $klantnaam);
// $sql->bindParam(":klantadres"    $klantadres);
// $sql->bindParam(":klantpostcode" $klantpostcode);
// $sql->bindParam(":klantplaats"   $klantplaats);

//$sql-> execute();

// manier 2 ------------------------


$sql->execute([
    "autokenteken"       =>$autokenteken,
    "automerk"     =>$automerk,
    "autotype"    =>$autotype,
    "autokmstand" =>$autokmstand,
    "klantid"    =>$klantid
]);

echo "de klant is toegevoegd <br />";
echo "<a href='gar-menu.php'> terug naar het menu </a>";
?>
</body>
</html>