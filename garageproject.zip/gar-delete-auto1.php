<!doctype html>
<html lang="nl">
<head></head>
<body>
<h1> garage delete auto 1</h1>
<form action="gar-delete-auto2.php" method="post">
    Welk kenteken wilt u verwijderen?
    <input type="text" name="autokentekenvak"> <br />
    <input type="submit">
</form>
</body>
</html>