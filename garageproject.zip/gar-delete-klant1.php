<!doctype html>
<html lang="nl">
<head></head>
<body>
<h1> garage delete klant 1</h1>
<form action="gar-delete-klant2.php" method="post">
    Welk klantid wilt u verwijderen?
    <input type="text" name="klantidvak"> <br />
    <input type="submit">
</form>
</body>
</html>