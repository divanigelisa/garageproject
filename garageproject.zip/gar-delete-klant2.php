<?php

// klantid uit het formulier halen
$klantid = $_POST["klantidvak"];

//klantgegevens uit de tabel halen
require_once "gar-connect.php";

$klanten = $conn->prepare("SELECT klantid, klantnaam, klantadres, klantpostcode, klantplaats FROM klant WHERE klantid = :klantid ");
$klanten->execute(["klantid" => $klantid]);

//klantgegevens laten zien
echo "<table>";
foreach ($klanten as $klant)
{
    echo "<tr>";
    echo "<td>" . $rij["klantid"] . "</td>";
    echo "<td>" . $rij["klantnaam"] . "</td>";
    echo "<td>" . $rij["klantadres"] . "</td>";
    echo "<td>" . $rij["klantpostcode"] . "</td>";
    echo "<td>" . $rij["klantplaats"] . "</td>";
    echo "</tr>";
}
echo "</table><br />";

echo "<form action='gar-delete-klant3.php' method='post'>";
// klantid mag niet meer gewijzigd worden
echo "<input type='hidden' name='klantidvak' value=$klantid>";
// waarde 0 doorgeven als er niet gecheckt wordt
echo "<input type='hidden' name = 'verwijdervak' value='0' >";
echo "<input type='checkbox' name = 'verwijdervak' value = '1'>";
echo "Verwijder deze klant. <br />";
echo "<input type = 'submit'>";
echo "</form>";