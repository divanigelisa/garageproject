<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>gar-create-klant1.php</title
    <link href="styles.css" rel="stylesheet" type="text/css">
</head>
<body>
<h1> Garage create klant 1</h1>
<p>
    Dit formulier wordt gebruikt om klantgegevens in te voeren.
</p>
<form action="gar-create-klant2.php" method="post">
    klantnaam:      <input type="text" name="klantnaamvak"> <br />
    klantadres:     <input type="text" name="klantadresvak"> <br />
    klantpostcode:  <input type="text" name="klantpostcodevak"> <br/>
    klantplaats:    <input type="text" name="klantplaatsvak">  <br />
    <input type="submit">
</form>
</body>
</html>