<?php

// klantgegevens uit het formulier halen

$autokenteken = $_POST["autokentekenvak"];
$automerk = $_POST["automerkvak"];
$autotype = $_POST["autotypevak"];
$autokmstand = $_POST["autokmstandvak"];
$klantid = $_POST["klantid"];

// updaten klantgegevens
require_once "gar-connect.php";

$sql = $conn->prepare(" UPDATE auto SET autokenteken = :autokenteken, automerk = :automerk, autotype = :autotype, autokmstand = :autokmstand WHERE autokenteken = :autokenteken");

$sql ->execute([ "autokenteken" => $autokenteken, "automerk" => $automerk, "autotype" => $autotype, "autokmstand" => $autokmstand, "klantid" => $klantid]);

echo "De klant is gewijigd. <br />";
echo "<a href= 'gar-menu.php'> Terug naar het menu </a>";