<!doctype html>
<html lang="nl">
<head> </head>
<body>
<h1> garage update klant 1</h1>
<p> Dit formulier wordt gebruikt om klantgegevens te wijzigen.</p>
<form action="gar-update-klant2.php" method="post">
    Welk klantid wilt u wijzigen?
    <input type="text" name="klantidvak"> <br/>
    <input type="submit">
</form>
</body>
</html>